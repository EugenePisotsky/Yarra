# Grass profiling report

Session: complete.

Power and clock context take priority over small HUD-duration differences. Invalid runs remain visible.

| Run | Status | App fps | GPU W | CPU W | GPU MHz | Active % | mJ/app frame | HUD GPU ms |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 01-fps60 | OK | 60.00 | 3.65 | 1.52 | 701.68 | 70.35 | 86.30 | 9.96 |
| 02-fps120 | OK | 119.73 | 16.05 | 4.54 | 1361.14 | 86.16 | 171.97 | 5.16 |
| 03-fps120 | MISSED TARGET | 103.35 | 9.33 | 2.90 | 813.36 | 95.43 | 118.29 | 9.29 |
| 04-fps60 | CHECK | 60.00 | 4.15 | 1.60 | 712.07 | 69.94 | 95.69 | 9.84 |

App-closed idle estimate: GPU 0.00 W, CPU 0.24 W. Not automatically subtracted.

mJ/app frame uses system CPU+GPU estimates divided by application updates, not independently counted presentations. HUD samples overlap. Power timestamps have approximately one-second alignment precision. The table does not declare an optimization winner or establish cross-device equivalence.

## 01-fps60

Settings: `{"counters": false, "density": "balanced", "fps": 60, "grass": "full", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: nominal. Power sampler: nominal.

## 02-fps120

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: nominal. Power sampler: nominal.

## 03-fps120

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: fair. Power sampler: heavy.
- Application update rate differs from requested target by >3%
- HUD presentation rate differs from target by >5%
- Elevated thermal pressure: inspect timeline and repeated-run order

## 04-fps60

Settings: `{"counters": false, "density": "balanced", "fps": 60, "grass": "full", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: fair, nominal. Power sampler: moderate, nominal.
- Elevated thermal pressure: inspect timeline and repeated-run order
