# Grass profiling report

Session: complete.

Power and clock context take priority over small HUD-duration differences. Invalid runs remain visible.

| Run | Status | App fps | GPU W | CPU W | GPU MHz | Active % | mJ/app frame | HUD GPU ms | HUD interval p95 ms |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 01-grass_on | OK | 60.00 | 2.97 | 1.71 | 714.10 | 73.80 | 77.97 | 9.74 | 16.67 |
| 02-grass_off | OK | 60.00 | 2.20 | 1.61 | 457.01 | 54.71 | 63.56 | 5.38 | 16.67 |
| 03-grass_off | OK | 60.00 | 0.92 | 1.69 | 532.05 | 49.38 | 43.41 | 4.94 | 16.67 |
| 04-grass_on | OK | 60.00 | 3.18 | 1.73 | 713.60 | 73.19 | 81.81 | 9.74 | 16.67 |

App-closed idle estimate: GPU 0.03 W, CPU 0.74 W. Not automatically subtracted.

mJ/app frame uses system CPU+GPU estimates divided by application updates, not independently counted presentations. HUD samples overlap. Power timestamps have approximately one-second alignment precision. The table does not declare an optimization winner or establish cross-device equivalence.

## 01-grass_on

Settings: `{"counters": false, "density": "balanced", "fps": 60, "grass": "full", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: nominal. Power sampler: nominal.

## 02-grass_off

Settings: `{"counters": false, "density": "balanced", "fps": 60, "grass": "off", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: nominal. Power sampler: nominal.

## 03-grass_off

Settings: `{"counters": false, "density": "balanced", "fps": 60, "grass": "off", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: nominal. Power sampler: nominal.

## 04-grass_on

Settings: `{"counters": false, "density": "balanced", "fps": 60, "grass": "full", "msaa": 4, "seconds": 120, "size": "2560x1440", "view": "low-walk", "warmup": 30}`

Application thermal states: nominal. Power sampler: nominal.
