"""Offline follow-up analysis for GP-019; use the archived analyzer beside this file."""
import collections
import json
from pathlib import Path
import statistics
import sys

import grass_profile_report as analyzer


def analyze(root):
    report = json.loads((root / 'report.json').read_text())
    run = report['runs'][0]
    begin, end = run['start_s'], run['end_s']
    power = report['power_samples']
    directory = root / 'runs' / run['name']
    meta = json.loads((directory / 'run.json').read_text())
    text = (directory / 'game.log').read_text()
    audits = [analyzer.fields(line) for line in text.splitlines() if 'RENDER_AUDIT ' in line]
    packets = []
    previous_payload = previous_time = None
    for line in text.splitlines():
        if 'metal-HUD: ' not in line:
            continue
        stamp = analyzer.timestamp(line, meta.get('local_utc_offset_seconds'))
        payload = line.split('metal-HUD: ', 1)[1].strip()
        if payload == previous_payload:
            continue
        previous_payload = payload
        if stamp is None:
            continue
        if previous_time is not None:
            values = list(map(float, payload.split(',')))
            if len(values) >= 5 and (len(values) - 3) % 2 == 0:
                packets.append({'start_s': previous_time, 'end_s': stamp,
                                'interval_ms': values[3::2], 'gpu_ms': values[4::2]})
        previous_time = stamp

    def window(lo, hi):
        samples = [s for s in run['samples']
                   if float(s['route_s']) - float(s['window_s']) >= lo - 1e-6
                   and float(s['route_s']) <= hi + 1e-6]
        duration = sum(float(s['window_s']) for s in samples)
        frames = sum(int(s['frames']) for s in samples)
        intervals = [v for p in packets if p['start_s'] >= begin + lo and p['end_s'] <= begin + hi
                     for v in p['interval_ms']]
        gpu = [v for p in packets if p['start_s'] >= begin + lo and p['end_s'] <= begin + hi
               for v in p['gpu_ms']]
        full = [s for s in samples if float(s['window_s']) >= .9]
        worst = min(full, key=lambda s: int(s['frames']) / float(s['window_s']), default=None)
        power_rows = [p for p in power if p['start_s'] >= begin + lo and p['end_s'] <= begin + hi]
        return {'from_s': lo, 'to_s': hi, 'fps': frames / duration if duration else None,
                'update_coverage_s': duration, 'frames': frames,
                'late_updates': sum(int(s['late_updates']) for s in samples),
                'max_interval_ms': max((float(s['update_max_ms']) for s in samples), default=None),
                'hud_samples': len(intervals), 'hud_interval_p95_ms': analyzer.quantile(intervals, .95),
                'hud_interval_max_ms': max(intervals, default=None),
                'hud_gpu_mean_ms': statistics.mean(gpu) if gpu else None,
                'hud_gpu_p95_ms': analyzer.quantile(gpu, .95),
                'worst_full_app_sample': worst,
                'min_gpu_mhz': min((p['gpu_mhz'] for p in power_rows if p['gpu_mhz'] is not None), default=None),
                'power': analyzer.power_window(power, begin + lo, begin + hi)}

    transitions = []
    previous = None
    for row in power:
        if row['thermal'] != previous:
            transitions.append({'seconds_from_measurement_start': row['end_s'] - begin,
                                'sample_end_unix_s': row['end_s'], 'state': row['thermal']})
            previous = row['thermal']
    app_transitions = []
    previous = None
    for row in audits:
        if row.get('thermal') != previous:
            app_transitions.append({'seconds_from_measurement_start': int(row['unix_ms']) / 1000 - begin,
                                    'state': row.get('thermal')})
            previous = row.get('thermal')
    pressure_seconds = collections.defaultdict(float)
    for row in power:
        if row['start_s'] >= begin and row['end_s'] <= end:
            pressure_seconds[row['thermal']] += row['duration_s']
    selected = [row for row in audits if begin <= int(row['unix_ms']) / 1000 <= end]
    comparisons = {}
    for path in sorted((root / 'comparison-inputs').glob('*.json')):
        old = json.loads(path.read_text())
        comparisons[path.stem] = {k: old[k] == run['inputs'][k]
                                 for k in ('binary_sha256', 'database_sha256', 'canopy_sha256', 'shader_sha256')}
    windows = [window(t, t + 30) for t in range(0, 900, 30)]
    return {'experiment': 'GP-019', 'session': root.name,
            'method': 'Whole update/power intervals inside each bin; boundaries excluded, not interpolated. HUD packets overlap; packet timestamps provide approximate grouping, not independent frame timings. Power timestamps have about one-second precision.',
            'user_observation': json.loads((root / 'user-observation.json').read_text()),
            'windows_10s': [window(t, t + 10) for t in range(0, 900, 10)], 'windows_30s': windows, 'windows_5min': [window(t, t + 300) for t in (0, 300, 600)],
            'focused_windows': [window(lo, hi) for lo, hi in ((260, 280), (705, 713), (770, 776), (833, 840), (425, 900))],
            'lowest_full_app_samples': sorted((s for s in run['samples'] if float(s['window_s']) >= .9),
                                             key=lambda s: int(s['frames']) / float(s['window_s']))[:15],
            'worst_30s_fps': min(w['fps'] for w in windows),
            'thermal_transitions': transitions, 'app_thermal_transitions': app_transitions,
            'measured_pressure_coverage_s': dict(pressure_seconds),
            'late_app_interval_fraction': run['updates']['late_updates'] / run['updates']['frames'],
            'audit_values': {k: sorted({row.get(k) for row in selected}) for k in
                             ('source_revision', 'source_pages', 'source_work_items', 'terrain_prepared_pages',
                              'terrain_prepared_active', 'render_px', 'surface_px', 'window_mode', 'monitor_hz')},
            'prior_input_hash_matches': comparisons}


if __name__ == '__main__':
    root = Path(sys.argv[1]).resolve()
    result = analyze(root)
    (root / 'analysis.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
