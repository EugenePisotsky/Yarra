"""Preserve GP-019 raw evidence and verify both analyzer versions offline."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import zipfile

import analyze_sustained
import grass_profile_report as original_analyzer


source = Path(__file__).resolve().parent.parent
repo = source.parents[2]
dest = repo / 'docs/performance' / source.name
dest.mkdir(parents=True, exist_ok=True)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


snapshots = source / 'reanalysis-source'
for name in ('tools/grass_profile_report.py', 'tools/grass_profile.py',
             'tools/test_grass_profile.py',
             'tools/profiles/grass-fullscreen-96-prepared-120.json',
             'tools/profiles/grass-fullscreen-96-default-120.json'):
    target = snapshots / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / name, target)

spec = importlib.util.spec_from_file_location('updated_report', snapshots / 'tools/grass_profile_report.py')
updated_analyzer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(updated_analyzer)

with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)
    for name in ('session.json', 'power.txt', 'user-observation.json'):
        shutil.copy2(source / name, root / name)
    for name in ('runs', 'comparison-inputs'):
        shutil.copytree(source / name, root / name)
    assert original_analyzer.write_report(root) == load(source / 'report.json')
    assert analyze_sustained.analyze(root) | {'session': source.name} == load(source / 'analysis.json')
    assert updated_analyzer.write_report(root) == load(source / 'reanalysis/report.json')

# Ensure the next control really has the same inputs, with only the arena changed.
candidate = load(repo / 'tools/profiles/grass-fullscreen-96-prepared-120.json')
control = load(repo / 'tools/profiles/grass-fullscreen-96-default-120.json')
assert control['defaults'] == candidate['defaults'] | {'prepared_blades': 131072}
run = load(source / 'report.json')['runs'][0]
inputs = run['inputs']
for key, sha_key in (('binary', 'binary_sha256'), ('world_db', 'database_sha256'), ('canopy', 'canopy_sha256')):
    assert digest(repo / control['defaults'][key]) == inputs[sha_key]
for name, sha in inputs['shader_sha256'].items():
    assert digest(repo / control['defaults']['shaders'] / name) == sha

files = [p for p in source.iterdir() if p.is_file() and p.suffix in ('.json', '.txt', '.md', '.html')]
files += list((source / 'runs').rglob('*.json')) + list((source / 'runs').rglob('*.log'))
files += list((source / 'analysis-tools').glob('*.py'))
files += list((source / 'comparison-inputs').glob('*.json'))
files += [p for p in snapshots.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [source / 'inputs/density96-prepared120' / name for name in ('inputs.json', 'canopy.ron')]
files += [source / 'reanalysis' / f'report.{extension}' for extension in ('json', 'md', 'html')]
entries = {}
with zipfile.ZipFile(dest / 'evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(set(files)):
        name = str(path.relative_to(source))
        archive.write(path, name)
        entries[name] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
with zipfile.ZipFile(dest / 'evidence.zip') as archive:
    assert archive.testzip() is None
    for name, info in entries.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == info['sha256']

for name in ('report.json', 'report.md', 'analysis.json', 'user-observation.json'):
    shutil.copy2(source / name, dest / name)
(dest / 'reanalysis').mkdir(exist_ok=True)
for extension in ('json', 'md', 'html'):
    shutil.copy2(source / 'reanalysis' / f'report.{extension}', dest / 'reanalysis' / f'report.{extension}')

manifest = {
    'experiment': 'GP-019', 'session': source.name,
    'zip_sha256': digest(dest / 'evidence.zip'), 'entries': entries,
    'verification': {
        'original_report_exactly_reproduced': True,
        'follow_up_analysis_exactly_reproduced': True,
        'updated_report_exactly_reproduced': True,
        'next_control_frozen_input_hashes_match_completed_run': True,
    },
    'local_inputs': str((source / 'inputs/density96-prepared120').relative_to(repo)),
    'next_control_inputs': 'tmp/grass-draw-density-20260916/density96-prepared/inputs',
    'input_hashes': inputs,
    'limits': 'Raw logs and analysis are portable. Large executable/database/shader assets stay local; unrelated assets were linked, not frozen. No fan RPM/temperature series.',
}
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'Verified original report, analysis, updated report, input hashes and {len(entries)} ZIP entries; { (dest / "evidence.zip").stat().st_size} bytes')
