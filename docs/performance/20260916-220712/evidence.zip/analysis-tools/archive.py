"""Preserve GP-020 and verify the original report and paired analysis."""
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import zipfile

import analyze_sustained
import compare_preparation
import grass_profile_report


source = Path(__file__).resolve().parent.parent
repo = source.parents[2]
dest = repo / 'docs/performance' / source.name
dest.mkdir(parents=True, exist_ok=True)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


snapshots = source / 'analysis-source'
for name in ('tools/grass_profile.py', 'tools/test_grass_profile.py',
             'tools/profiles/grass-fullscreen-96-prepared-120.json',
             'tools/profiles/grass-fullscreen-96-default-120.json'):
    target = snapshots / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / name, target)

with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary) / source.name
    root.mkdir()
    for name in ('session.json', 'power.txt', 'user-observation.json'):
        shutil.copy2(source / name, root / name)
    for name in ('runs', 'comparison-inputs', 'comparison-source'):
        shutil.copytree(source / name, root / name)
    assert grass_profile_report.write_report(root) == load(source / 'report.json')
    analysis = analyze_sustained.analyze(root)
    assert analysis == load(source / 'analysis.json')
    (root / 'analysis.json').write_text(json.dumps(analysis))
    assert compare_preparation.compare(root) == load(source / 'comparison.json')

run = load(source / 'report.json')['runs'][0]
inputs = source / 'inputs/density96-default120'
for file, key in (('game', 'binary_sha256'), ('runtime.sqlite', 'database_sha256'), ('canopy.ron', 'canopy_sha256')):
    assert digest(inputs / file) == run['inputs'][key]
for name, sha in run['inputs']['shader_sha256'].items():
    assert digest(inputs / 'assets/shaders' / name) == sha

files = [p for p in source.iterdir() if p.is_file() and p.suffix in ('.json', '.txt', '.md', '.html')]
files += list((source / 'runs').rglob('*.json')) + list((source / 'runs').rglob('*.log'))
files += list((source / 'analysis-tools').glob('*.py'))
files += list((source / 'comparison-inputs').glob('*.json'))
files += list((source / 'comparison-source').glob('*.json'))
files += [p for p in snapshots.rglob('*') if p.is_file()]
files += [inputs / name for name in ('inputs.json', 'canopy.ron')]
entries = {}
with zipfile.ZipFile(dest / 'evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(set(files)):
        name = str(path.relative_to(source))
        archive.write(path, name)
        entries[name] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
with zipfile.ZipFile(dest / 'evidence.zip') as archive:
    assert archive.testzip() is None
    for name, info in entries.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == info['sha256']

for name in ('report.json', 'report.md', 'report.html', 'analysis.json', 'comparison.json', 'user-observation.json'):
    shutil.copy2(source / name, dest / name)

manifest = {
    'experiment': 'GP-020', 'session': source.name,
    'zip_sha256': digest(dest / 'evidence.zip'), 'entries': entries,
    'verification': {
        'original_report_exactly_reproduced': True,
        'follow_up_analysis_exactly_reproduced': True,
        'paired_comparison_exactly_reproduced': True,
        'local_snapshot_hashes_verified': True,
        'sole_setting_difference_prepared_blades': True,
    },
    'local_inputs': str(inputs.relative_to(repo)),
    'input_hashes': run['inputs'],
    'limits': 'Raw logs and analysis are portable. Large executable/database/shader assets stay local; other assets were linked, not frozen. No fan RPM/temperature series. One chronological pair, not counterbalanced repeats.',
}
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'Verified original report, analysis, paired comparison, input hashes and {len(entries)} ZIP entries; { (dest / "evidence.zip").stat().st_size} bytes')
