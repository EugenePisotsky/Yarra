"""GP-020 matched preparation comparison. All inputs are archived JSON/logs."""
import json
from pathlib import Path
import sys


def load(path):
    return json.loads(path.read_text())


def summarize(report, analysis):
    run = report['runs'][0]
    full = [s for s in run['samples'] if float(s['window_s']) >= .9]
    worst = min(full, key=lambda s: int(s['frames']) / float(s['window_s']))
    return {
        'session': analysis['session'], 'prepared_blades': run['settings']['prepared_blades'],
        'whole_run': {k: run[k] for k in ('updates', 'power', 'hud')},
        'worst_full_app_window': worst,
        'final_five_minutes': analysis['windows_5min'][-1],
        'thermal_transitions': analysis['thermal_transitions'],
        'idle': report['idle'], 'power_source_at_start': report['session']['host']['power_source'],
    }


def compare(root):
    candidate_report = load(root / 'comparison-source/report.json')
    candidate_analysis = load(root / 'comparison-source/analysis.json')
    control_report = load(root / 'report.json')
    control_analysis = load(root / 'analysis.json')
    a, b = candidate_report['runs'][0], control_report['runs'][0]
    settings_difference = {k: {'enlarged': a['settings'].get(k), 'default': b['settings'].get(k)}
                           for k in a['settings'].keys() | b['settings'].keys()
                           if a['settings'].get(k) != b['settings'].get(k)}
    matches = {k: a['inputs'][k] == b['inputs'][k]
               for k in ('binary_sha256', 'database_sha256', 'canopy_sha256', 'shader_sha256')}
    assert all(matches.values())
    assert settings_difference == {'prepared_blades': {'enlarged': 524288, 'default': 131072}}
    enlarged = summarize(candidate_report, candidate_analysis)
    default = summarize(control_report, control_analysis)
    deltas = {}
    for period, ak, bk in (
        ('whole_run', a['power'], b['power']),
        ('final_five_minutes', enlarged['final_five_minutes']['power'], default['final_five_minutes']['power']),
    ):
        deltas[period] = {
            k: {'enlarged_minus_default': ak[k] - bk[k],
                'enlarged_relative_to_default_percent': 100 * (ak[k] / bk[k] - 1)}
            for k in ('gpu_w', 'cpu_w', 'cpu_gpu_w', 'gpu_mhz', 'gpu_active_percent')
        }
    return {
        'experiment': 'GP-020', 'scope': 'One chronological enlarged/default pair; no counterbalanced repeat.',
        'input_hash_matches': matches, 'settings_difference': settings_difference,
        'enlarged': enlarged, 'default': default, 'power_deltas': deltas,
        'limits': [
            'Power estimates cover CPU/GPU subsystems, not isolated game watts or wall power.',
            'Final five-minute windows use whole intervals; short stalls remain included.',
            'App windows and overlapping HUD packets do not provide an independent presentation 1% low.',
            'Battery was 100% charged for enlarged, 98% charging for default; temperatures/fan RPM were not measured.',
            'Repeated stalls and clock/power changes are correlated; direction of causality is unresolved.',
        ],
        'decision': 'Do not promote enlarged capacity as an energy/thermal optimization. Keep it opt-in; retain original production capacity. Diagnose recurring stalls before increasing density.',
    }


if __name__ == '__main__':
    root = Path(sys.argv[1]).resolve()
    (root / 'comparison.json').write_text(json.dumps(compare(root), indent=2, allow_nan=False) + '\n')
