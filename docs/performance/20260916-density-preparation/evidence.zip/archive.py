import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
source=Path(__file__).resolve().parent
dest=ROOT/'docs/performance/20260916-density-preparation'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files=[]
for name in ['capture.py','diagnostics.py','validate_prepared.py','archive.py','density-diagnostics.json',
             'preparation-comparison.json','preparation-validation.json','smoke.json']:
 files.append(source/name)
for dirname in ['baseline72','density96-default','density96-prepared']:
 folder=source/dirname
 files += [p for p in folder.iterdir() if p.is_file() and p.suffix in ['.json','.log','.csv']]
 files += [folder/'inputs/inputs.json',folder/'inputs/canopy.ron']
for folder in source.glob('diagnostic-*'):
 files += [p for p in folder.iterdir() if p.is_file() and p.suffix in ['.log','.json']]
files += [source/'cooked/source-catalog.ron',source/'cooked/manifest.json']
for folder in (source/'cooked').glob('density-*'):
 files += [folder/'catalog.ron',folder/'cook.log']
files += [p for p in (source/'smoke').rglob('*') if p.is_file() and not p.is_symlink()
          and 'assets' not in p.parts and p.suffix in ['.json','.log','.txt','.md']]
entries={}
with zipfile.ZipFile(dest/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):
  name=str(p.relative_to(source));z.write(p,name);entries[name]=digest(p)
 for name in ['tools/grass_profile.py','tools/grass_profile_report.py','tools/grass_density_variants.py',
              'tools/summarize_gpu_counters.py','tools/profiles/grass-fullscreen-96-prepared-120.json',
              'crates/app_game/src/profile.rs','crates/vegetation_render/src/renderer/blade_preparation.rs',
              'crates/world_cook/src/main.rs']:
  p=ROOT/name;arc='analysis-source/'+name;z.write(p,arc);entries[arc]=digest(p)
shots=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':digest(p)}
       for p in sorted(source.glob('diagnostic-*/view-*.png'))]
manifest={'zip_sha256':digest(dest/'evidence.zip'),'entries_sha256':entries,
          'local_screenshots':shots,'local_native_traces':[str(p.relative_to(ROOT)) for p in source.glob('*/frame.gputrace')],
          'local_inputs':'tmp/grass-draw-density-20260916/density96-prepared/inputs',
          'notes':'Native traces, binaries, databases and PNGs remain local; original earlier evidence archives untouched.'}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['preparation-comparison.json','preparation-validation.json','density-diagnostics.json']:
 (dest/name).write_bytes((source/name).read_bytes())
with zipfile.ZipFile(dest/'evidence.zip') as z:
 assert z.testzip() is None
 for name,sha in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
print('Archive verified',len(entries),'entries', (dest/'evidence.zip').stat().st_size,'bytes; screenshots',len(shots))
