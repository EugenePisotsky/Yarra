import json, os, sys, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from grass_profile import snapshot, save, check_other_games, stop
root=Path(__file__).resolve().parent
name=sys.argv[1] if len(sys.argv)>1 else 'baseline72'
run=root/name
run.mkdir()
settings={'world_db':sys.argv[2]} if len(sys.argv)>2 else {}
meta=snapshot(run/'inputs',settings)
(run/'assets').symlink_to(run/'inputs/assets',target_is_directory=True)
cmd=[str(run/'inputs/game'),'--world-db',str(run/'inputs/runtime.sqlite'),'--canopy-look',str(run/'inputs/canopy.ron'),'--render-repro','low-walk','--profile-diagnostic','--profile-size','game','--profile-window','fullscreen','--profile-fps','120','--profile-msaa','4','--grass-density','balanced','--metal-capture',str(run/'frame.gputrace')]
if len(sys.argv)>3: cmd += ['--grass-prepared-blades',sys.argv[3]]
save(run/'command.json',cmd)
check_other_games()
p=None
try:
    env=dict(os.environ,MTL_CAPTURE_ENABLED='1',RUST_LOG='warn',NO_COLOR='1')
    for key in ['MTL_HUD_ENABLED','MTL_HUD_LOG_ENABLED','METAL_DEVICE_WRAPPER_TYPE','MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']:env.pop(key,None)
    with (run/'game.log').open('w') as out:
        p=subprocess.Popen(cmd,cwd=run,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT)
        code=p.wait(timeout=120)
    save(run/'result.json',{'exit_code':code,'trace_exists':(run/'frame.gputrace').is_dir()})
    print((run/'game.log').read_text()[-11000:])
    if code or not (run/'frame.gputrace').is_dir():raise RuntimeError('Capture failed')
finally:stop(p)
