import sys,subprocess,os
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[1]/'tools'))
from grass_profile import check_other_games,save,stop
check_other_games()
inputs=root/'baseline72/inputs' # Original capture folder was named before catalog decoding (actual 66).
for density in [66,72,96,128]:
    run=root/f'diagnostic-{density}'
    run.mkdir()
    (run/'assets').symlink_to(inputs/'assets',target_is_directory=True)
    cmd=[str(inputs/'game'),'--world-db',str(root/f'cooked/density-{density}/runtime.sqlite'),
         '--canopy-look',str(inputs/'canopy.ron'),'--render-repro','low-walk','--profile-diagnostic',
         '--profile-size','game','--profile-window','fullscreen','--profile-fps','120',
         '--profile-msaa','4','--grass-density','balanced','--grass-counters','--render-frames','1800',
         '--render-snapshot',str(run/'view.png'),'--render-snapshot-frames','600,900']
    save(run/'command.json',cmd)
    env=dict(os.environ,RUST_LOG='warn',NO_COLOR='1')
    for key in ['MTL_CAPTURE_ENABLED','MTL_HUD_ENABLED','MTL_HUD_LOG_ENABLED','METAL_DEVICE_WRAPPER_TYPE','MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']:env.pop(key,None)
    p=None
    try:
        with (run/'game.log').open('w') as out:
            p=subprocess.Popen(cmd,cwd=run,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT)
            code=p.wait(timeout=120)
        save(run/'result.json',{'exit_code':code})
        print(f'{density} complete exit={code}',flush=True)
        if code:raise RuntimeError('Game diagnostic failed')
    finally:stop(p)
