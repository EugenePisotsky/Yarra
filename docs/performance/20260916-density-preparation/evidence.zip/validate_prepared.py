import json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[1]/'tools'))
from grass_profile import check_other_games,save,stop
check_other_games()
inputs=root/'density96-prepared/inputs'
mode=sys.argv[1] if len(sys.argv)>1 else 'prepared'
capacity='131072' if mode!='prepared' else '524288'
run=root/f'diagnostic-96-{mode}-matched'
run.mkdir()
(run/'assets').symlink_to(inputs/'assets',target_is_directory=True)
cmd=[str(inputs/'game'),'--world-db',str(inputs/'runtime.sqlite'),'--canopy-look',str(inputs/'canopy.ron'),
 '--render-repro','low-walk','--profile-diagnostic','--profile-size','game','--profile-window','fullscreen',
 '--profile-fps','120','--profile-msaa','4','--grass-density','balanced','--grass-prepared-blades',capacity,
 '--grass-counters','--render-frames','1800','--render-snapshot',str(run/'view.png'),
 '--render-snapshot-frames','600,900']
save(run/'command.json',cmd)
p=None
try:
 env=dict(os.environ,RUST_LOG='warn',NO_COLOR='1')
 for key in ['MTL_CAPTURE_ENABLED','MTL_HUD_ENABLED','MTL_HUD_LOG_ENABLED','METAL_DEVICE_WRAPPER_TYPE','MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']:env.pop(key,None)
 with (run/'game.log').open('w') as log:
  p=subprocess.Popen(cmd,cwd=run,env=env,stdout=log,stderr=subprocess.STDOUT)
  code=p.wait(timeout=120)
 save(run/'result.json',{'exit_code':code})
 print('prepared diagnostic complete',code)
finally:stop(p)
