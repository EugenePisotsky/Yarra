"""Summarize actual Metal GPU intervals, not the CPU encoder-creation table."""
import collections
import json
from pathlib import Path
import statistics
import sys
import xml.etree.ElementTree as ET


def analyze(path, pid=21735, start_s=1, end_s=3):
    root = ET.parse(path).getroot()
    schema = root.find('.//schema')
    assert schema.get('name') == 'metal-gpu-intervals'
    columns = [c.findtext('mnemonic') for c in schema.findall('col')]
    objects = {e.get('id'): e for e in root.iter() if e.get('id')}

    def resolve(e):
        while e.get('ref'):
            e = objects[e.get('ref')]
        return e

    def label(e):
        e = resolve(e)
        return e.get('fmt') or e.text or ''

    events = []
    for row in root.findall('.//row'):
        cells = dict(zip(columns, row, strict=True))
        process = resolve(cells['process'])
        p = process.find('pid')
        if p is None or int(resolve(p).text) != pid or label(cells['state']) != 'Active':
            continue
        begin = int(resolve(cells['start']).text)
        finish = begin + int(resolve(cells['duration']).text)
        title = label(cells['event-label']).split('      (')[0].strip()
        events.append({'start_ns': begin, 'end_ns': finish,
                       'stage': label(cells['channel-name']), 'label': title,
                       'encoder_id': resolve(cells['encoder-id']).text})

    def union_ns(intervals):
        merged = []
        for a, b in sorted(intervals):
            if merged and a <= merged[-1][1]:
                merged[-1][1] = max(b, merged[-1][1])
            else:
                merged.append([a, b])
        return sum(b - a for a, b in merged)

    begin, end = int(start_s * 1e9), int(end_s * 1e9)
    encoders = collections.defaultdict(list)
    for event in events:
        encoders[event['encoder_id']].append(event)
    grouped = collections.defaultdict(list)
    for encoder_id, rows in encoders.items():
        if not encoder_id or encoder_id == '0':
            continue
        # Include all stages of an encoder, or omit that boundary-crossing encoder.
        if min(r['start_ns'] for r in rows) < begin or max(r['end_ns'] for r in rows) > end:
            continue
        stages = collections.defaultdict(list)
        for row in rows:
            stages[(row['stage'], row['label'])].append((row['start_ns'], row['end_ns']))
        for key, intervals in stages.items():
            grouped[key].append(union_ns(intervals) / 1e6)
    summaries = [{'stage': k[0], 'label': k[1], 'encoder_count': len(values),
                  'mean_stage_ms': statistics.mean(values),
                  'p95_stage_ms': sorted(values)[int((len(values) - 1) * .95)],
                  'sum_stage_ms': sum(values)} for k, values in grouped.items()]
    summaries.sort(key=lambda s: s['sum_stage_ms'], reverse=True)
    active_ns = union_ns((max(begin, e['start_ns']), min(end, e['end_ns'])) for e in events
                         if e['end_ns'] > begin and e['start_ns'] < end)
    assert 0 <= active_ns <= end - begin
    return {'pid': pid, 'trace_window_s': [start_s, end_s],
            'source_table': 'metal-gpu-intervals',
            'method': 'GPU execution intervals for target PID, grouped by encoder and hardware stage. Only fully contained encoders enter stage means. Segments are unioned per encoder/stage; concurrent stages are not summed into frame latency. Metal frame-number field is not used as an application-frame count.',
            'limitations': 'Short instrumented moving-scene sample, default/adaptive performance state, no simultaneous power capture, no shader counter set. Main opaque pass combines grass/terrain/objects. Does not establish fixed-clock capacity, sustained headroom, grass-only draw time or watts.',
            'target_active_interval_union_ms': active_ns / 1e6,
            'stages': summaries}


if __name__ == '__main__':
    root = Path(sys.argv[1])
    result = analyze(root / 'gpu-intervals.xml')
    (root / 'analysis.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    for item in result['stages'][:8]:
        print(item['stage'], item['label'], item['encoder_count'], round(item['mean_stage_ms'], 4))
