# Grass profiling report

Session: complete.
Power collector: macmon. macmon uses private macOS APIs; estimates are system-wide.

Power and clock context take priority over small HUD-duration differences. Invalid runs remain visible.

| Run | Status | Window | World pixels | Surface pixels | App fps | Worst app window fps | GPU W | CPU W | GPU MHz | Active % | mJ/app frame | HUD GPU ms | HUD interval p95 ms |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 01-lod | OK | fullscreen | 2592x1456 | 3456x2168 | 120.00 | 119.90 | 22.59 | 6.16 | 1360.59 | 88.62 | 239.65 | 5.58 | 8.33 |
| 02-legacy | OK | fullscreen | 2592x1456 | 3456x2168 | 119.83 | 117.04 | 18.01 | 5.30 | 1272.80 | 82.00 | 194.53 | 4.53 | 8.33 |
| 03-lod | OK | fullscreen | 2592x1456 | 3456x2168 | 120.00 | 119.93 | 23.33 | 6.18 | 1367.86 | 89.26 | 245.85 | 5.57 | 8.33 |

App-closed idle estimate: GPU — W, CPU — W. Not automatically subtracted.

mJ/app frame uses system CPU+GPU estimates divided by application updates, not independently counted presentations. Worst app window uses sampling windows of at least 0.9 seconds (normally about one second), not a 1% low or presentation counter. HUD samples overlap. Power timestamps have approximately one-second alignment precision. The table does not declare an optimization winner or establish cross-device equivalence.

## 01-lod

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 30, "size": "2592x1456", "terrain_lod": true, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 119.90 fps over 1.001 s, ending 8.03 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 0 / 3600.

## 02-legacy

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 30, "size": "2592x1456", "terrain_lod": false, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 117.04 fps over 1.008 s, ending 13.06 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 6 / 3595.

## 03-lod

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 30, "size": "2592x1456", "terrain_lod": true, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 119.93 fps over 1.001 s, ending 20.09 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 0 / 3600.
