# Grass profiling report

Session: complete.

Power and clock context take priority over small HUD-duration differences. Invalid runs remain visible.

| Run | Status | Window | World pixels | Surface pixels | App fps | Worst app window fps | GPU W | CPU W | GPU MHz | Active % | mJ/app frame | HUD GPU ms | HUD interval p95 ms |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 01-legacy | CHECK | fullscreen | 2592x1456 | 3456x2168 | 119.92 | 118.99 | — | — | — | — | — | 4.59 | 8.33 |
| 02-lod | MISSED TARGET | fullscreen | 2592x1456 | 3456x2168 | 116.15 | 92.54 | — | — | — | — | — | 7.27 | 8.33 |
| 03-legacy | CHECK | fullscreen | 2592x1456 | 3456x2168 | 119.95 | 118.65 | — | — | — | — | — | 4.58 | 8.33 |

App-closed idle estimate: GPU — W, CPU — W. Not automatically subtracted.

mJ/app frame uses system CPU+GPU estimates divided by application updates, not independently counted presentations. Worst app window uses sampling windows of at least 0.9 seconds (normally about one second), not a 1% low or presentation counter. HUD samples overlap. Power timestamps have approximately one-second alignment precision. The table does not declare an optimization winner or establish cross-device equivalence.

## 01-legacy

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 60, "size": "2592x1456", "terrain_lod": false, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 118.99 fps over 1.000 s, ending 48.23 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 5 / 7195.
- Power telemetry covers less than 80% of measurement window

## 02-lod

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 600, "size": "2592x1456", "terrain_lod": true, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: fair, nominal. Power sampler: unavailable.

Worst app window: 92.54 fps over 1.016 s, ending 192.93 s into measurement. Windows below 95% of target: 137 (138.04 s of sampled time). Late updates: 2310 / 69693.
- Application update rate differs from requested target by >3%
- Brief/periodic cadence loss: 137 full app sampling window(s) below 95% of target; inspect the timeline even if average FPS passes
- Elevated thermal pressure: inspect timeline and repeated-run order
- Power telemetry covers less than 80% of measurement window

## 03-legacy

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 60, "size": "2592x1456", "terrain_lod": false, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: fair. Power sampler: unavailable.

Worst app window: 118.65 fps over 1.003 s, ending 27.11 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 3 / 7197.
- Elevated thermal pressure: inspect timeline and repeated-run order
- Power telemetry covers less than 80% of measurement window
