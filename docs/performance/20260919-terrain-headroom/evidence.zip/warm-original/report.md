# Grass profiling report

Session: complete.

Power and clock context take priority over small HUD-duration differences. Invalid runs remain visible.

| Run | Status | Window | World pixels | Surface pixels | App fps | Worst app window fps | GPU W | CPU W | GPU MHz | Active % | mJ/app frame | HUD GPU ms | HUD interval p95 ms |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 01-lod-original-warm | CHECK | fullscreen | 2592x1456 | 3456x2168 | 118.88 | 87.59 | — | — | — | — | — | 6.31 | 8.33 |

App-closed idle estimate: GPU — W, CPU — W. Not automatically subtracted.

mJ/app frame uses system CPU+GPU estimates divided by application updates, not independently counted presentations. Worst app window uses sampling windows of at least 0.9 seconds (normally about one second), not a 1% low or presentation counter. HUD samples overlap. Power timestamps have approximately one-second alignment precision. The table does not declare an optimization winner or establish cross-device equivalence.

## 01-lod-original-warm

Settings: `{"binary": null, "candidate_reference": false, "canopy": null, "counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "placement_reference": false, "prepared_blades": null, "prepass": true, "seconds": 30, "shaders": "tmp/terrain-gpu-headroom/original-shaders", "size": "2592x1456", "terrain_lod": true, "terrain_reference": false, "vertex_reference": false, "view": "grass-soak", "warmup": 5, "window": "fullscreen", "world_db": null}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 87.59 fps over 1.005 s, ending 1.00 s into measurement. Windows below 95% of target: 1 (1.00 s of sampled time). Late updates: 38 / 3567.
- Brief/periodic cadence loss: 1 full app sampling window(s) below 95% of target; inspect the timeline even if average FPS passes
- Power telemetry covers less than 80% of measurement window
