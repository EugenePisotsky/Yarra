# Grass profiling report

Session: complete.
Power collector: macmon. macmon uses private macOS APIs; estimates are system-wide.

Power and clock context take priority over small HUD-duration differences. Invalid runs remain visible.

| Run | Status | Window | World pixels | Surface pixels | App fps | Worst app window fps | GPU W | CPU W | GPU MHz | Active % | mJ/app frame | HUD GPU ms | HUD interval p95 ms |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 01-baseline | OK | fullscreen | 2592x1456 | 3456x2168 | 120.00 | 119.96 | 20.52 | 6.06 | 1278.43 | 90.08 | 221.48 | 5.79 | 8.33 |
| 02-neighbor-bypass | OK | fullscreen | 2592x1456 | 3456x2168 | 120.00 | 119.95 | 19.14 | 6.16 | 1203.88 | 88.98 | 210.83 | 5.91 | 8.33 |
| 03-baseline | OK | fullscreen | 2592x1456 | 3456x2168 | 120.00 | 119.93 | 20.38 | 6.50 | 1256.33 | 88.45 | 223.98 | 5.89 | 8.33 |

App-closed idle estimate: GPU — W, CPU — W. Not automatically subtracted.

mJ/app frame uses system CPU+GPU estimates divided by application updates, not independently counted presentations. Worst app window uses sampling windows of at least 0.9 seconds (normally about one second), not a 1% low or presentation counter. HUD samples overlap. Power timestamps have approximately one-second alignment precision. The table does not declare an optimization winner or establish cross-device equivalence.

## 01-baseline

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 25, "size": "2592x1456", "terrain_lod": true, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 119.96 fps over 1.000 s, ending 1.00 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 0 / 3000.

## 02-neighbor-bypass

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 25, "shaders": "tmp/terrain-review/neighbors-bypass", "size": "2592x1456", "terrain_lod": true, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 119.95 fps over 1.000 s, ending 18.07 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 0 / 3000.

## 03-baseline

Settings: `{"counters": false, "density": "balanced", "fps": 120, "grass": "full", "msaa": 4, "native_pacing": true, "prepass": true, "seconds": 25, "size": "2592x1456", "terrain_lod": true, "view": "grass-soak", "warmup": 15, "window": "fullscreen"}`

Observed display: `{"monitor_hz": "120.000", "monitor_px": "3456x2234", "render_px": "2592x1456", "scale_factor": "2", "surface_px": "3456x2168", "window_logical": "1728x1084", "window_mode": "fullscreen"}`

Application thermal states: nominal. Power sampler: unavailable.

Worst app window: 119.93 fps over 1.001 s, ending 9.03 s into measurement. Windows below 95% of target: 0 (0.00 s of sampled time). Late updates: 0 / 3000.
