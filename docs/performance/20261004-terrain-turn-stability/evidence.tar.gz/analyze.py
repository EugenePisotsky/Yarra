from pathlib import Path
import sys,re,json,statistics,datetime,hashlib
sys.path.insert(0,str(Path('tools').resolve()))
from grass_profile_report import timestamp,quantile

def analyze(path):
    lines=path.read_text().splitlines()
    def fields(s): return dict(re.findall(r'(\w+)=([^\s]+)',s))
    start=fields(next(l for l in lines if 'GRASS_PROFILE event=measure_start' in l))
    end=fields(next(l for l in lines if 'GRASS_PROFILE event=complete' in l))
    begin=int(start['unix_ms'])/1000; finish=int(end['unix_ms'])/1000
    gpu=[];interval=[];old=None;prev=None;thermal=set();focus=set()
    for l in lines:
        f=fields(l)
        if 'unix_ms' in f and begin<=int(f['unix_ms'])/1000<=finish:
            if 'focused' in f:focus.add(f['focused'])
            if 'thermal' in f:thermal.add(f['thermal'])
        if 'metal-HUD: ' not in l: continue
        stamp=timestamp(l,10800);payload=l.split('metal-HUD: ',1)[1].strip()
        if payload==old:continue
        old=payload
        if stamp is None:continue
        inside=prev is not None and prev>=begin and stamp<=finish
        prev=stamp
        if not inside:continue
        vals=list(map(float,payload.split(',')))
        gpu.extend(vals[4::2]);interval.extend(vals[3::2])
    lod=[]
    for l in lines:
        if 'TERRAIN_LOD ' not in l:continue
        v=dict(re.findall(r'(\w+): ([\w.]+)',l))
        lod.append(v)
    return {'profile_end':end,'focused':sorted(focus),'thermal':sorted(thermal),'hud':{'samples':len(gpu),'gpu_median_ms':statistics.median(gpu),'gpu_mean_ms':statistics.mean(gpu),'gpu_p95_ms':quantile(gpu,.95),'presentation_median_ms':statistics.median(interval),'presentation_mean_ms':statistics.mean(interval),'presentation_p95_ms':quantile(interval,.95),'scope':'Correlated Metal HUD samples; clock/power not measured. See manifest for FPS cap.'},'terrain':{'max_mesh_mib':max(int(v.get('mesh_bytes',0)) for v in lod)/1048576,'max_cached_mesh_mib':max(int(v.get('cached_mesh_bytes',0)) for v in lod)/1048576,'max_material_detail_tiles':max(int(v.get('material_detail_tiles',0)) for v in lod),'max_unmorphed_swaps':max(int(v.get('unmorphed_swaps',0)) for v in lod),'last':lod[-1]}}
results={}
for name in sys.argv[1:]:
    path=Path('/private/tmp/reteya_turn_stability')/name
    results[name]=analyze(path)
print(json.dumps(results,indent=2))
